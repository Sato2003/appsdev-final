import base64
import customtkinter as ctk
import os
import zipfile
import tempfile
import pyzipper
import secrets
from tkinter import messagebox, filedialog, simpledialog
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.fernet import Fernet
from PIL import Image

# Initialize app
root = ctk.CTk()
root.geometry("500x500")
root.title("Encryption App")
root.resizable(False, False)

# Center window
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
position_top = int(screen_height / 2 - 500 / 2)
position_right = int(screen_width / 2 - 500 / 2)
root.geometry(f'500x500+{position_right}+{position_top}')

ctk.set_appearance_mode("light")
root.config(bg="sky blue")

account_file = "accounts.txt"

bg_image = ctk.CTkImage(Image.open(r"image\download1.png"), size=(500, 500))
bg_label = ctk.CTkLabel(root, image=bg_image, text="")
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

def load_accounts():
    accounts = {}
    if os.path.exists(account_file):
        try:
            with open(account_file, "r") as file:
                for line in file:
                    username, email, password = line.strip().split(",")
                    accounts[username] = {'email': email, 'password': password}
        except Exception as e:
            messagebox.showerror("File Error", f"Error loading accounts: {e}")
    return accounts


def save_account(username, email, password):
    try:
        with open(account_file, "a") as file:
            file.write(f"{username},{email},{password}\n")
    except Exception as e:
        messagebox.showerror("File Error", f"Error saving account: {e}")


accounts = load_accounts()


def caesar_cipher(text, mode='encrypt', key=3):
    result = ""
    for char in text:
        if char.isalpha():
            shift = key if mode == 'encrypt' else -key
            base = ord('A') if char.isupper() else ord('a')
            result += chr((ord(char) - base + shift) % 26 + base)
        else:
            result += char
    return result


def show_notification(frame, message, color="#FF4444"):
    notif_label = ctk.CTkLabel(frame, text=message, text_color=color, font=("Arial", 12, "bold"))
    notif_label.pack(pady=5)
    notif_label.after(3000, notif_label.destroy)


def switch_frame(target_frame):
    login_frame.pack_forget()
    sign_in_frame.pack_forget()
    encryption_frame.pack_forget()
    target_frame.pack(padx=25, pady=25, expand=True)


# Toggle password visibility
def toggle_password_visibility(entry, checkbox_var):
    if checkbox_var.get():
        entry.configure(show="")
    else:
        entry.configure(show="*")


# ---------- Login Frame ----------
login_frame = ctk.CTkFrame(root, width=400, height=400, corner_radius=20, fg_color="#FFFFFF")
login_frame.pack(padx=25, pady=25, expand=True)

login_title = ctk.CTkLabel(login_frame, text="Login", font=("Arial", 24, "bold"))
login_title.pack(pady=10)

login_username_entry = ctk.CTkEntry(login_frame, placeholder_text="Username")
login_username_entry.pack(pady=5, padx=20, fill="x")

login_password_entry = ctk.CTkEntry(login_frame, placeholder_text="Password", show="*")
login_password_entry.pack(pady=5, padx=20, fill="x")

login_show_password_var = ctk.BooleanVar()
login_show_password_checkbox = ctk.CTkCheckBox(
    login_frame, text="Show Password", variable=login_show_password_var,
    command=lambda: toggle_password_visibility(login_password_entry, login_show_password_var)
)
login_show_password_checkbox.pack(pady=2)


def login_action():
    username = login_username_entry.get()
    password = login_password_entry.get()

    if username == "" or password == "":
        messagebox.showerror("Missing Info", "Please enter both username and password.")
    elif username in accounts and accounts[username]["password"] == password:
        messagebox.showinfo("Login Successful", "You have successfully logged in.")
        switch_frame(encryption_frame)
    else:
        messagebox.showerror("Login Failed", "Account not found. Please sign up.")
        login_username_entry.delete(0, 'end')
        login_password_entry.delete(0, 'end')


login_button = ctk.CTkButton(login_frame, text="Login", command=login_action, fg_color="#4CAF50", hover_color="#45A049")
login_button.pack(pady=10)

signup_button = ctk.CTkButton(login_frame, text="Sign Up", command=lambda: switch_frame(sign_in_frame),
                              fg_color="#2196F3", hover_color="#1976D2")
signup_button.pack(pady=5)

# ---------- Sign In Frame ----------
sign_in_frame = ctk.CTkFrame(root, width=400, height=400, corner_radius=20, fg_color="#FFFFFF")

sign_in_title = ctk.CTkLabel(sign_in_frame, text="Sign Up", font=("Arial", 24, "bold"))
sign_in_title.pack(pady=10)

sign_in_username_entry = ctk.CTkEntry(sign_in_frame, placeholder_text="Username")
sign_in_username_entry.pack(pady=5, padx=20, fill="x")

sign_in_email_entry = ctk.CTkEntry(sign_in_frame, placeholder_text="Email")
sign_in_email_entry.pack(pady=5, padx=20, fill="x")

sign_in_password_entry = ctk.CTkEntry(sign_in_frame, placeholder_text="Password", show="*")
sign_in_password_entry.pack(pady=5, padx=20, fill="x")

signup_show_password_var = ctk.BooleanVar()
signup_show_password_checkbox = ctk.CTkCheckBox(
    sign_in_frame, text="Show Password", variable=signup_show_password_var,
    command=lambda: toggle_password_visibility(sign_in_password_entry, signup_show_password_var)
)
signup_show_password_checkbox.pack(pady=2)


def sign_up_action():
    username = sign_in_username_entry.get()
    email = sign_in_email_entry.get()
    password = sign_in_password_entry.get()

    if username == "" or email == "" or password == "":
        messagebox.showerror("Missing Info", "Please fill in all fields.")
    elif not email.endswith("@gmail.com"):
        messagebox.showerror("Invalid Email", "Please enter a valid Gmail address (e.g., example@gmail.com).")
    elif username in accounts:
        messagebox.showerror("Duplicate", "Username already exists.")
    else:
        save_account(username, email, password)
        accounts[username] = {'email': email, 'password': password}
        sign_in_username_entry.delete(0, 'end')
        sign_in_email_entry.delete(0, 'end')
        sign_in_password_entry.delete(0, 'end')
        login_username_entry.delete(0, 'end')
        login_password_entry.delete(0, 'end')
        switch_frame(login_frame)
        messagebox.showinfo("Success", "Account successfully created!")


sign_up_button = ctk.CTkButton(sign_in_frame, text="Sign Up", command=sign_up_action, fg_color="#4CAF50",
                               hover_color="#45A049")
sign_up_button.pack(pady=10)

back_to_login = ctk.CTkButton(sign_in_frame, text="Back to Login", command=lambda: switch_frame(login_frame),
                              fg_color="#F44336", hover_color="#D32F2F")
back_to_login.pack(pady=5)

# ---------- Encryption Frame ----------
encryption_frame = ctk.CTkFrame(root, width=400, height=400, corner_radius=20, fg_color="#FFFFFF")

encrypt_title = ctk.CTkLabel(encryption_frame, text="Text Encryption", font=("Arial", 20, "bold"))
encrypt_title.pack(pady=10)

placeholder = "Enter the text"
text_entry = ctk.CTkTextbox(encryption_frame, width=350, height=100, corner_radius=10, fg_color="white", border_width=2)
text_entry.insert("1.0", placeholder)
text_entry.configure(text_color="gray")
text_entry.pack(pady=5, padx=20, fill="x")
passwordFrame = ctk.CTkFrame(encryption_frame, fg_color='white')
password_entry = ctk.CTkEntry(passwordFrame, placeholder_text="Enter password for encryption", show="*")
password_entry.pack(pady=5, padx=20, fill="x")

encryption_show_password_var = ctk.BooleanVar()
encryption_show_password_checkbox = ctk.CTkCheckBox(
    passwordFrame, text="Show Password", variable=encryption_show_password_var,
    command=lambda: toggle_password_visibility(password_entry, encryption_show_password_var)
)
encryption_show_password_checkbox.pack(pady=2)

def on_focus_in(event):
    if text_entry.get("1.0", "end-1c") == placeholder:
        text_entry.delete("1.0", "end")
        text_entry.configure(text_color="black")


def on_focus_out(event):
    if text_entry.get("1.0", "end-1c").strip() == "":
        text_entry.insert("1.0", placeholder)
        text_entry.configure(text_color="gray")


text_entry.bind("<FocusIn>", on_focus_in)
text_entry.bind("<FocusOut>", on_focus_out)

result_label = ctk.CTkLabel(encryption_frame, text="", wraplength=350)
result_label.pack(pady=1)

def encrypt_message():
    text = text_entry.get("1.0", "end-1c").strip()

    if not text:
        messagebox.showerror("Missing Text", "Please enter the text to encrypt.")
        return

    try:
        dummy_password = "fixed-internal-password"
        salt = secrets.token_bytes(16)

        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=390000,
            backend=default_backend()
        )
        key = base64.urlsafe_b64encode(kdf.derive(dummy_password.encode()))
        fernet = Fernet(key)

        encrypted_text = fernet.encrypt(text.encode())

        result = f"SALT:{base64.b64encode(salt).decode()}\n{encrypted_text.decode()}"

        text_entry.delete("1.0", "end")
        text_entry.insert("1.0", result)
        result_label.configure(text="Text encrypted successfully.")

    except Exception as e:
        messagebox.showerror("Encryption Error", f"An error occurred:\n{e}")


def decrypt_message():
    try:
        text = text_entry.get("1.0", "end-1c").strip()
        lines = text.splitlines()

        if not lines or not lines[0].startswith("SALT:"):
            messagebox.showerror("Format Error", "Invalid encrypted text format.")
            return

        salt_b64 = lines[0][5:]
        encrypted_data_b64 = ''.join(lines[1:])

        salt = base64.b64decode(salt_b64)
        encrypted_data = encrypted_data_b64.encode()

        internal_password = "fixed-internal-password"

        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=390000,
            backend=default_backend()
        )
        key = base64.urlsafe_b64encode(kdf.derive(internal_password.encode()))
        fernet = Fernet(key)

        decrypted_data = fernet.decrypt(encrypted_data).decode()

        text_entry.delete("1.0", "end")
        text_entry.insert("1.0", decrypted_data)
        result_label.configure(text="Text decrypted successfully.")

    except Exception as e:
        messagebox.showerror("Decryption Failed", f"An error occurred during decryption:\n{e}")

def save_file():
    passwordFrame.pack_forget()
    for widget in passwordFrame.winfo_children():
        widget.destroy()

    passwordFrame.pack(after=text_entry, pady=10, padx=20, fill="x")

    password_entry = ctk.CTkEntry(passwordFrame, placeholder_text="Enter password", show="*")
    password_entry.pack(pady=5, padx=20, fill="x")

    encryption_show_password_checkbox = ctk.CTkCheckBox(
        passwordFrame, text="Show Password", variable=encryption_show_password_var,
        command=lambda: toggle_password_visibility(password_entry, encryption_show_password_var)
    )
    encryption_show_password_checkbox.pack(pady=2)

    def finalize_save():
        password = password_entry.get()
        if not password:
            messagebox.showerror("Error", "Password is required.")
            return

        encrypted_content = text_entry.get("1.0", "end-1c").strip()
        if not encrypted_content:
            messagebox.showerror("Error", "Text field is empty.")
            return

        file_path = filedialog.asksaveasfilename(defaultextension=".zip", filetypes=[("ZIP files", "*.zip")])
        if not file_path:
            return

        try:
            temp_file = "encrypted_text.txt"
            with open(temp_file, "w") as f:
                f.write(encrypted_content)

            with pyzipper.AESZipFile(file_path, 'w', compression=pyzipper.ZIP_LZMA, encryption=pyzipper.WZ_AES) as zf:
                zf.setpassword(password.encode())
                zf.write(temp_file, arcname="encrypted_text.txt")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save ZIP: {e}")
            return
        finally:
            if os.path.exists(temp_file):
                os.remove(temp_file)

        text_entry.delete("1.0", "end")
        password_entry.delete(0, "end")
        passwordFrame.pack_forget()
        messagebox.showinfo("Success", "Encrypted text saved in password-protected ZIP.")

    confirm_btn = ctk.CTkButton(passwordFrame, text="Encrypt and Save", command=finalize_save)
    confirm_btn.pack(pady=5)


def load_file():
    file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt"), ("ZIP files", "*.zip")])
    if not file_path:
        return

    try:
        if file_path.lower().endswith('.zip'):
            for widget in passwordFrame.winfo_children():
                widget.destroy()
            passwordFrame.pack(after=text_entry, pady=10, padx=20, fill="x")

            password_entry = ctk.CTkEntry(passwordFrame, placeholder_text="Enter ZIP password", show="*")
            password_entry.pack(pady=5, padx=20, fill="x")

            show_password_cb = ctk.CTkCheckBox(
                passwordFrame, text="Show Password", variable=encryption_show_password_var,
                command=lambda: toggle_password_visibility(password_entry, encryption_show_password_var)
            )
            show_password_cb.pack(pady=2)

            def finalize_load():
                zip_pwd = password_entry.get().strip()
                if not zip_pwd:
                    messagebox.showerror("Missing Password", "Please enter the ZIP file's password.")
                    return

                try:
                    with tempfile.TemporaryDirectory() as temp_dir:
                        with pyzipper.AESZipFile(file_path, 'r') as zipf:
                            zipf.pwd = zip_pwd.encode('utf-8')
                            zipf.extractall(temp_dir)

                        extracted_files = os.listdir(temp_dir)
                        if not extracted_files:
                            messagebox.showerror("Empty ZIP", "The ZIP file is empty.")
                            return

                        extracted_file_path = os.path.join(temp_dir, extracted_files[0])
                        with open(extracted_file_path, "r") as file:
                            encrypted_text = file.read()

                        text_entry.delete("1.0", "end")
                        text_entry.insert("1.0", encrypted_text)
                        text_entry.configure(text_color="black")

                        messagebox.showinfo("File Loaded", "Encrypted file loaded successfully.")
                        passwordFrame.pack_forget()

                except RuntimeError as e:
                    messagebox.showerror("Incorrect Password", "The password you entered is incorrect for this ZIP file.")
                except pyzipper.BadZipFile:
                    messagebox.showerror("Invalid ZIP", "The selected file is not a valid ZIP file.")
                except Exception as e:
                    messagebox.showerror("Load Error", f"Failed to load the ZIP file: {e}")

            confirm_btn = ctk.CTkButton(passwordFrame, text="Load File", command=finalize_load)
            confirm_btn.pack(pady=5)

        else:
            with open(file_path, "r") as file:
                loaded_text = file.read()
            text_entry.delete("1.0", "end")
            text_entry.insert("1.0", loaded_text)
            text_entry.configure(text_color="black")
            messagebox.showinfo("File Loaded", "Text file loaded successfully.")

    except Exception as e:
        messagebox.showerror("File Error", f"Error loading file: {e}")

def logout():
    encryption_frame.pack_forget()
    login_frame.pack(fill="both", expand=True)


top_button_frame = ctk.CTkFrame(encryption_frame, fg_color="transparent")
top_button_frame.pack(pady=10)

encrypt_button = ctk.CTkButton(top_button_frame, text="Encrypt", command=encrypt_message, fg_color="#4CAF50",
                               hover_color="#45A049")
encrypt_button.pack(side="left", padx=10)

decrypt_button = ctk.CTkButton(top_button_frame, text="Decrypt", command=decrypt_message, fg_color="#FF9800",
                               hover_color="#FB8C00")
decrypt_button.pack(side="left", padx=10)

middle_button_frame = ctk.CTkFrame(encryption_frame, fg_color="transparent")
middle_button_frame.pack(pady=10)

save_button = ctk.CTkButton(middle_button_frame, text="Save to Secure ZIP", command=save_file, fg_color="#3F51B5",
                            hover_color="#303F9F")
save_button.pack(side="left", padx=10)

load_button = ctk.CTkButton(middle_button_frame, text="Load File", command=load_file, fg_color="#2196F3",
                            hover_color="#1976D2")
load_button.pack(side="left", padx=10)

logout_button = ctk.CTkButton(encryption_frame, text="Logout", command=lambda: switch_frame(login_frame),
                              fg_color="#F44336", hover_color="#D32F2F")
logout_button.pack(pady=20)

root.mainloop()